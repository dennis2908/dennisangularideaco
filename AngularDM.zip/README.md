# Instalasi dan menjalankan project di localhost:

1. install angular 11.2.14
2. git clone https://github.com/dennis2908/dennisangularideaco
3. buka cmd dan lalu ketik yarn install dan enter
4. setelah berhasil install, lalu ketik npm start dan enter
5. buka http://localhost:4200 di browser (prefer mozilla)

# Notes :

  - Login : </br>
     
	Username : console </br>
	
	Password : myconsole </br>
	
  - localhost harus terkoneksi dengan internet <br>
  
  - Untuk sorting dapat dilakukan dengan meng klik judul kolom Id, Username, First Name, Last Name <br>
  
  - Untuk searching dapat dilakukan dengan mengisi textbox di bawah judul kolom Username, First Name, Last Name <br>
	
	
# Bukti running : (project angular ini yg sudah di deploy online)

  https://dennisangular.herokuapp.com 
	